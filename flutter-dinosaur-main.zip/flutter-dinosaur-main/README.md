# Flutter Dinosaur Game

A simple chrome dinosaur game build with flutter.

## Gameplay Preview

![](gameplay.gif "Gameplay")

## Downloads
v1.1 (apk) [Download](https://github.com/HeveshL/flutter-dinosaur/releases/download/1.1/app-release.apk)

v1.0 (apk) [Download](https://github.com/HeveshL/flutter-dinosaur/releases/download/1.0/app-release.apk)