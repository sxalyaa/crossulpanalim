class Sprite {
  late String imagePath;
  late int imageWidth;
  late int imageHeight;
}
