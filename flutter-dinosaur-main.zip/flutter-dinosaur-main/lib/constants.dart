int gravity = 2500;
const int worlToPixelRatio = 10;
double initialVelocity = 30;
double acceleration = 1;
int dayNightOffest = 1000;
double jumpVelocity = 850;
