package com.example.flutter_dinosaur

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
